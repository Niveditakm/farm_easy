<?php 
session_start();

include "../config/database.php";

$id = 0;

if(isset($_POST['butdel'])){
   $id = mysqli_real_escape_string($link,$_POST['butdel']);
}
else
{
    echo"<script> location.replace('viewproducts.php') </script>";
}

if($id > 0){

  // Check record exists
  $checkRecord = mysqli_query($link,"SELECT * FROM farm_2021_product WHERE id=".$id);

  $totalrows = mysqli_num_rows($checkRecord);

  if($totalrows > 0)
  {
	  
    $query = "DELETE FROM farm_2021_product WHERE id=".$id;
    mysqli_query($link,$query);
	
	$_SESSION["remove"] = 'success';
    echo"<script> location.replace('viewproducts.php') </script>";
   
  }
  else
  {
    $_SESSION["remove"] = 'failed';
    echo"<script> location.replace('viewproducts.php') </script>";
  }
}
?>