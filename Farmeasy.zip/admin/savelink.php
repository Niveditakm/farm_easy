<?php
session_start();

require "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

    $linkone = $_POST["linkone"];
    $linktwo = $_POST["linktwo"];
    $linkthree = $_POST["linkthree"];
    $linkfour = $_POST["linkfour"];

    $checkRecord = mysqli_query($link, "SELECT * FROM farm_2021_link");

    $totalrows = mysqli_num_rows($checkRecord);

    if ($totalrows <= 0) 
    {

        $query = "insert into farm_2021_link values('','$linkone','$linktwo','$linkthree','$linkfour')";

        $result = mysqli_query($link, $query);


        if ($result) 
        {
            $_SESSION["add"] = "success";
            echo "<script> location.replace('addlinks.php') </script>";
        } 
        else 
        {
            $_SESSION['add'] = "failed";
            echo "<script> location.replace('addlinks.php') </script>";
        }
    } 
    else 
    {
        $query = "update farm_2021_link set farm_2021_link_one = '$linkone', farm_2021_link_two = '$linktwo', farm_2021_link_three = '$linkthree', farm_2021_link_four = '$linkfour'";

        $result = mysqli_query($link, $query);


        if ($result) 
        {
            $_SESSION["add"] = "success";
            echo "<script> location.replace('addlinks.php') </script>";
        } 
        else 
        {
            $_SESSION['add'] = "failed";
            echo "<script> location.replace('addlinks.php') </script>";
        }
    }

    mysqli_close($link);
}
